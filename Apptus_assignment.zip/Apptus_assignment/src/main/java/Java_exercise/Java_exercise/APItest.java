package Java_exercise.Java_exercise;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.Test;

import com.google.gson.Gson;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APItest {
	
public Properties loadProperties() throws IOException {
		
		//calling properties file
		Properties prop=new Properties();
		String prop_filepath = "resources/api_input.properties";
		FileInputStream ip= new FileInputStream(prop_filepath);
	    prop.load(ip);
		return prop;
	}
	@Test
	public void Invalidapitest() throws IOException, ParseException {
		
		JSONParser jsonParser = new JSONParser();
		String filepath ="resources/payload1.json";
		FileReader reader = new FileReader(filepath);
		Object obj = jsonParser.parse(reader);
		
		Properties prop = new Properties();
		prop= loadProperties();
		
		RestAssured.baseURI= prop.getProperty("baseURI");

		String response=given()
				.log().all().header("Content-Type",prop.getProperty("content_type"))
				.body(obj.toString())
				.when()
				.post(prop.getProperty("resource_get_noapikey"))
				.then()
				.assertThat().statusCode(401)
				.extract().response().getStatusLine();
		System.out.println(response);

	}
	@Test
	public int apitest1() throws IOException, ParseException {
		
		JSONParser jsonParser = new JSONParser();
		String filepath ="resources/payload1.json";
		FileReader reader = new FileReader(filepath);
		Object obj = jsonParser.parse(reader);
		
		Properties prop = new Properties();
		prop= loadProperties();
		
		
		
		RestAssured.baseURI= prop.getProperty("baseURI");

		String response=given()
				.log().all().header("Content-Type",prop.getProperty("content_type"))
				.body(obj.toString())
				.when()
				.post(prop.getProperty("resource_get"))
				.then()
				.assertThat().statusCode(201)
				.extract().response().asString();
		
		JsonPath js=new JsonPath(response);
		int stationid=js.get("ID");
		String station= String.valueOf(stationid);
				
		System.out.println(stationid);
		System.out.println(response);
		
		return stationid;

	}
	@Test
	public int apitest2() throws IOException, ParseException {
		
		JSONParser jsonParser = new JSONParser();
		String filepath ="resources/payload2.json";
		FileReader reader = new FileReader(filepath);
		Object obj = jsonParser.parse(reader);
		
		Properties prop = new Properties();
		prop= loadProperties();
		
		RestAssured.baseURI= prop.getProperty("baseURI");

		String response=given()
				.log().all().header("Content-Type",prop.getProperty("content_type"))
				.body(obj.toString())
				.when()
				.post(prop.getProperty("resource_get"))
				.then()
				.assertThat().statusCode(201)
				.extract().response().asString();
		
		JsonPath js=new JsonPath(response);
		int stationid=js.get("ID");
		String station= String.valueOf(stationid);
				
		System.out.println(stationid);
		System.out.println(response);
		
		return stationid;

	}
	//Get request to check the station ids
	@Test
	public void getapi() throws IOException, ParseException {
		
		Properties prop = new Properties();
		prop= loadProperties();
		APItest input1 = new APItest();
		int	id = input1.apitest1();
		RestAssured.baseURI= prop.getProperty("baseURI");
		
		String response=given().pathParam("id", id)
				.log().all().header("Content-Type",prop.getProperty("content_type"))
				.when()
				.get(prop.getProperty("resource_get"))
				.then()
				.assertThat().statusCode(200)
				.extract().response().getStatusLine();
		System.out.println(response);

	}
	//Deleting the station code
	@Test
	public void deleteapi() throws IOException, ParseException {
		
		Properties prop = new Properties();
		prop= loadProperties();
		APItest input2 = new APItest();
		int	id = input2.apitest1();
		RestAssured.baseURI= prop.getProperty("baseURI");
		
		String response=given().pathParam("id", id)
				.log().all().header("Content-Type",prop.getProperty("content_type"))
				.when()
				.delete(prop.getProperty("resource_get"))
				.then()
				.assertThat().statusCode(204)
				.extract().response().getStatusLine();
		System.out.println(response);

	}
}
