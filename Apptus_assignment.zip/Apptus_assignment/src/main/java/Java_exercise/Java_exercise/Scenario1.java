package Java_exercise.Java_exercise;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.http.util.Asserts;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Scenario1 {
	WebDriver driver;
	String driverpath= "resources//chromedriver.exe";
	
	@BeforeTest()
	public Properties loadProperties() throws IOException {
		
		//calling properties file
		Properties prop=new Properties();
		String prop_filepath = "resources/input.properties";
		FileInputStream ip= new FileInputStream(prop_filepath);
	    prop.load(ip);
		return prop;
	}
	@Test()
	public void Shopping() throws InterruptedException, IOException {
		
		Properties prop = new Properties();
		prop= loadProperties();
		
		System.setProperty("webdriver.chrome.driver", driverpath);
		driver = new ChromeDriver();	
		driver.get(prop.getProperty("URL"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 30);
		//FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver).withTimeout(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(prop.getProperty("signin_xpath"))));
		WebElement signin =driver.findElement(By.xpath(prop.getProperty("signin_xpath")));
		signin.click();
		WebElement username= driver.findElement(By.xpath(prop.getProperty("username_xpath")));
		username.sendKeys(prop.getProperty("username"));
		WebElement Password= driver.findElement(By.xpath(prop.getProperty("password_xpath")));
		Password.sendKeys(prop.getProperty("password"));
		WebElement submit= driver.findElement(By.xpath(prop.getProperty("submitbutton_xpath")));
		submit.click();
		WebElement selectCategory= driver.findElement(By.xpath(prop.getProperty("category_xpath")));
		selectCategory.click();
		WebElement selectItem= driver.findElement(By.xpath(prop.getProperty("itemselection_xpath")));
		selectItem.click();
		WebElement AddtoCart= driver.findElement(By.xpath(prop.getProperty("addtocart_xpath")));
		AddtoCart.click();
		WebElement Checkout= driver.findElement(By.xpath(prop.getProperty("proceedtocheckout_xpath")));
		Checkout.click();
		
		WebElement productname =driver.findElement(By.xpath(prop.getProperty("productname_xpath")));
		String productname_actualvalue = productname.getText();
		System.out.println("Product name is:" +productname_actualvalue);
		String productname_expectedvalue = "Faded Short Sleeve T-shirts";
		Assert.assertEquals(productname_actualvalue, productname_expectedvalue);
		
		WebElement productDesc =driver.findElement(By.xpath(prop.getProperty("productDesc_xpath")));
		String productDesc_actualvalue = productDesc.getText();
		System.out.println("Product Description is:" +productDesc_actualvalue);
		String productDesc_expectedvalue = "Color : Orange, Size : S";
		Assert.assertEquals(productDesc_actualvalue, productDesc_expectedvalue);
		
		WebElement productQuantity =driver.findElement(By.xpath(prop.getProperty("quantity_xpath")));
		String productQuantity_actualvalue = productQuantity.getText();
		System.out.println("Product Quantity is:" +productQuantity_actualvalue);
		String productQuantity_expectedvalue = "1 Product";
		Assert.assertEquals(productQuantity_actualvalue, productQuantity_expectedvalue);
		
		WebElement productPrice =driver.findElement(By.xpath(prop.getProperty("price_xpath")));
		String productPrice_actualvalue = productPrice.getText();
		System.out.println("Product price is:" +productPrice_actualvalue);
		String productPrice_expectedvalue = "$16.51";
		Assert.assertEquals(productPrice_actualvalue, productPrice_expectedvalue);
		
		driver.quit();
		
}
}
